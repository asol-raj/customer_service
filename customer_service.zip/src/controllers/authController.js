const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const User = require('../models/user');
const { jwtSecret, jwtExpiry } = require('../config/auth');

const saltRounds = 10;

const AuthController = {
  // Register customer
  register: async (req, res) => {
    try {
      const { email, password } = req.body;

      const existingUser = await User.findByEmail(email);
      if (existingUser) {
        return res.status(400).json({ message: 'Email already registered' });
      }

      const hashedPassword = await bcrypt.hash(password, saltRounds);
      const userId = await User.create(email, hashedPassword, 'customer');

      return res.status(201).json({ message: 'Registration successful', userId });
    } catch (err) {
      console.error(err);
      return res.status(500).json({ message: 'Server error' });
    }
  },

  // Login (customer or staff)
  login: async (req, res) => {
    try {
      const { email, password } = req.body;

      const user = await User.findByEmail(email);
      if (!user) return res.status(401).render('login', { error: 'Invalid credentials' });

      const passwordMatch = await bcrypt.compare(password, user.password_hash);
      if (!passwordMatch) return res.status(401).render('login', { error: 'Invalid credentials' });

      // Create JWT payload
      const payload = { id: user.id, email: user.email, user_type: user.user_type };

      const token = jwt.sign(payload, jwtSecret, { expiresIn: jwtExpiry });

      // Set JWT in HTTP-only cookie
      res.cookie('auth_token', token, {
        httpOnly: true,
        secure: process.env.NODE_ENV === 'production', // only HTTPS in production
        maxAge: 1000 * 60 * 60 * 8 // 8 hours
      });

      // Redirect based on user_type
      if (user.user_type === 'customer') {
        res.redirect('/auth/ticket'); // customer ticket page
      } else if (user.user_type === 'staff') {
        res.redirect('/dashboard'); // staff dashboard
      } else {
        res.redirect('/'); // fallback
      }

    } catch (err) {
      console.error(err);
      res.status(500).render('login', { error: 'Server error' });
    }
  }
};

module.exports = AuthController;
