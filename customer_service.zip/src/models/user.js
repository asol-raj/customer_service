// ./src/model/user.js
const pool = require('../config/db');

const User = {
  // Create a new user
  create: async (email, passwordHash, userType = 'customer') => {
    const [result] = await pool.query(
      `INSERT INTO users (email, password_hash, user_type) VALUES (?, ?, ?)`,
      [email, passwordHash, userType]
    );
    return result.insertId;
  },

  // Find user by email
  findByEmail: async (email) => {
    const [rows] = await pool.query(
      `SELECT * FROM users WHERE email = ? LIMIT 1`,
      [email]
    );
    return rows[0] || null;
  },

  // Find user by ID
  findById: async (id) => {
    const [rows] = await pool.query(
      `SELECT * FROM users WHERE id = ? LIMIT 1`,
      [id]
    );
    return rows[0] || null;
  },

  // Get all users (basic info)
  getAll: async () => {
    const [rows] = await pool.query(
      `SELECT id, email, user_type, created_at FROM users`
    );
    return rows;
  },

  // Delete user by ID
  delete: async (id) => {
    const [result] = await pool.query(
      `DELETE FROM users WHERE id = ?`,
      [id]
    );
    return result.affectedRows > 0;
  }
};

module.exports = User;
